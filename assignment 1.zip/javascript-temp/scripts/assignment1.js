let dateOfUpload = "May 2022";
let totalViews = "100000";
let totalLikes = "2000333";
let totalDislikes="444";
let totalSubscribers= "1000000";
let nameOfPage= "My Page";
let typeOfVideo= "Short";
let videoCatagory= "sports";
let notifications= "20";
let uploads= "10";
let search= "search";
let shorts= "shorts";
let channelSubscriptions= "29";
let videoHistory= "video History";
let videosToWatchLater= "videos to watch later";
let videoInfo= "video onfo";
let videoAuthor= "BoB";
let channelName= "BoBs Channel";
let trendingVideos= "Trending Videos";
let shopping= "shopping";





document.write(`
    <p>Date: ${dateOfUpload}</p>
    <p>view: ${totalViews}</p>
    <p>Likes: ${totalLikes}</p>
    <p>Dislikes: ${totalDislikes}</p>
    <p>Subscribers: ${totalSubscribers}</p>
    <p>Page Name: ${nameOfPage}</p>
    <p>Video Type: ${typeOfVideo}</p>
    <p>Catagory: ${videoCatagory}</p>
    <p>Notifications: ${notifications}</p>
    <p>Uploads: ${uploads}</p>
    <p>Search: ${search}</p>
    <p>Shorts: ${shorts}</p>
    <p>Subscriptions: ${channelSubscriptions}</p>
    <p>History: ${videoHistory}</p>
    <p>Watch Later: ${videosToWatchLater}</p>
    <p>video Info: ${videoInfo}</p>
    <p>Video Author: ${videoAuthor}</p>
    <p>Channel Name: ${channelName}</p>
    <p>Trending: ${trendingVideos}</p>
    <p>Shopping: ${shopping}</p>

    `


);
